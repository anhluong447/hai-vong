"""Reproducible cuts of the retained CC0 recording; no synthetic footstep layers."""
import json,math,struct,wave,hashlib
from pathlib import Path
folder=Path(__file__).resolve().parent
with wave.open(str(folder/'wood-shoes-1518.wav'),'rb') as source:
    rate=source.getframerate();channels=source.getnchannels();width=source.getsampwidth();raw=source.readframes(source.getnframes())
assert channels==1 and width in (2,3,4)
samples=[int.from_bytes(raw[i:i+width],'little',signed=True)/(1<<(8*width-1)) for i in range(0,len(raw),width)]
window=rate//100
energies=[sum(v*v for v in samples[i:i+window])/window for i in range(0,len(samples)-window,window)]
candidates=sorted((v,i) for i,v in enumerate(energies) if 2<i/100<30)
selected=[]
for energy,index in reversed(candidates):
    if all(abs(index-other)>65 for other in selected):selected.append(index)
    if len(selected)==4:break
cuts=[]
for number,index in enumerate(sorted(selected),1):
    start=max(0,index*window-int(rate*.04));segment=samples[start:start+int(rate*.28)]
    peak=max(abs(v) for v in segment);gain=min(2,.72/max(peak,.001))
    pcm=b''.join(struct.pack('<h',round(max(-1,min(1,v*gain))*32767*min(1,i/(rate*.004),(len(segment)-1-i)/(rate*.012)))) for i,v in enumerate(segment))
    name='wood-step-'+str(number)+'.wav'
    with wave.open(str(folder/name),'wb') as out:out.setparams((1,2,rate,0,'NONE','not compressed'));out.writeframes(pcm)
    cuts.append({'file':name,'startFrame':start,'frames':len(segment),'rate':rate,'gain':gain,'fadeInSeconds':.004,'fadeOutSeconds':.012,'sha256':hashlib.sha256((folder/name).read_bytes()).hexdigest()})
with wave.open(str(folder/'silence.wav'),'wb') as out:out.setparams((1,2,rate,0,'NONE','not compressed'));out.writeframes(bytes(round(rate*.05)*2))
(folder/'CUTS.json').write_text(json.dumps({'source':'wood-shoes-1518.wav','selection':'four strongest separated 10ms energy windows in 2..30s; sorted chronologically','cuts':cuts,'silence':'explicit 0.05s zero samples for pressure cue; not foley'},indent=2)+'\n',encoding='utf-8')
print(json.dumps(cuts))
